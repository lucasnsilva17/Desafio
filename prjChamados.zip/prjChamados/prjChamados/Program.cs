﻿using prjChamados.Model;
using prjChamados.View;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjChamados
{

    public class Program
    {

        Chamados chamado;
        clsUsuario user;

        /// <summary>
        /// Ponto de entrada principal para o aplicativo.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmMenu());
        }

        public Boolean FazerLogin(string matricula, string senha) // metodo responsavel pela validação do login
        {
            user = new clsUsuario();

            user.matricula = matricula;
            user.senha = senha;

            if (user.ValidaAcesso())
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public void IniciaChamado(int nroChamado, string matricula)
        {
            frmAssumirChamado frm = new frmAssumirChamado(nroChamado, matricula);
            frm.Visible = true;
        }

        public Boolean AssumirChamado(int nroChamado, string nroMatricula)
        {
            chamado = new Chamados();
            if (chamado.AtribuirChamado(nroChamado, nroMatricula))
                return true;
            return false;
        }

        public Boolean FecharChamado(int nroChamado, string solucao, string matricula)
        {
            chamado = new Chamados();
            if (chamado.EncerrarChamado(nroChamado, solucao))
            {                
                frmListaChamado lista = new frmListaChamado(matricula);
                lista.Visible = true;
                return true;
            }
            else
            {
                return false;
            }
        }

        public int CadChamado(string nome, string setor, string problema, string descricao)
        {
            int nroChamado;
            Chamados chamado = new Chamados(nome, setor, problema, descricao);

            nroChamado = chamado.InsertBD();
            return nroChamado;

        }

        public Boolean CadUsuario(string matricula, string nome)
        {
            user = new clsUsuario();
            user.nome = nome;
            user.matricula = matricula;

            if (user.CadastrarUsuario())
                return true;
            else
                return false;
        }

        public Boolean AlterarSenha(string matricula, string senha)
        {
            clsUsuario user = new clsUsuario();
            user.matricula = matricula;
            user.senha = senha;

            if (user.AlteraSenha())
                return true;
            else
                return false;
        }

        public string OwnerChamado(int nroChamado)
        {
            chamado = new Chamados();
            string MatriculaOwner;

            MatriculaOwner = chamado.OwnerChamado(nroChamado); 

            return MatriculaOwner;
        }

        public DataTable CarregaGridChamadosFechados()
        {
            chamado = new Chamados();
            return chamado.CarregaGridChamadosFechados();
        }

        public DataTable PesquisaGridChamadosFechados(int opcao, string condicao)
        {
            chamado = new Chamados();
            return chamado.PesquisaGridChamadosFechados(opcao, condicao);
        }

        public DataTable CarregaGridChamadosAbertos()
        {
            chamado = new Chamados();
            return chamado.CarregaGridChamadosAbertos();
        }

        public DataTable PesquisaGridChamadosAbertos(int opcao, string condicao)
        {
            chamado = new Chamados();
            return chamado.PesquisaGridChamadosAbertos(opcao, condicao);
        }

        public Boolean GeraPDF(string nroChamado)
        {
            chamado = new Chamados();
            return chamado.GeraPDF(nroChamado);
        }

        public void VoltarListaChamados(string matricula)
        {
            frmListaChamado frm = new frmListaChamado(matricula);
            frm.Visible = true;
        }

        public void AbrirPDF(int nroChamado)
        {
            chamado = new Chamados();
            chamado.AbrirPDF(nroChamado);
        }
    }

}
