﻿namespace prjChamados
{
}

namespace prjChamados
{


    public partial class DataSetChamados
    {
    }
}
namespace prjChamados {
    
    
    public partial class DataSetChamados {
    }
}

namespace prjChamados.DataSetChamadosTableAdapters {
    
    
    public partial class ChamadosTableAdapter {
    }
}
