USE [master]
GO

/****** Object:  Table [dbo].[chamados]    Script Date: 19/04/2017 18:30:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[chamados](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[solicitante] [varchar](50) NOT NULL,
	[problemas] [varchar](50) NOT NULL,
	[descricao] [varchar](50) NOT NULL,
	[dataAbert] [varchar](30) NOT NULL,
	[statusChamado] [varchar](10) NOT NULL,
	[id_func] [varchar](50) NULL,
	[dataFechamento] [varchar](30) NULL,
	[setor] [varchar](50) NULL,
	[solucao] [varchar](200) NULL,
	[tempoAberto] [varchar](30) NULL,
 CONSTRAINT [pk_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[chamados]  WITH CHECK ADD  CONSTRAINT [fk_id_fun] FOREIGN KEY([id_func])
REFERENCES [dbo].[funcionarioAtendente] ([matricula])
GO

ALTER TABLE [dbo].[chamados] CHECK CONSTRAINT [fk_id_fun]
GO

ALTER TABLE [dbo].[chamados]  WITH CHECK ADD  CONSTRAINT [ck_statusChamado] CHECK  (([statusChamado]='FECHADO' OR [statusChamado]='ABERTO'))
GO

ALTER TABLE [dbo].[chamados] CHECK CONSTRAINT [ck_statusChamado]
GO


