USE [master]
GO

/****** Object:  Table [dbo].[funcionarioAtendente]    Script Date: 19/04/2017 18:31:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[funcionarioAtendente](
	[matricula] [varchar](50) NOT NULL,
	[nome] [varchar](50) NOT NULL,
	[senha] [varchar](20) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[matricula] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


